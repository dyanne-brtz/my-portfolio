# Dark Feminine Student Portfolio

A beginner-friendly responsive portfolio built with HTML, CSS, and JavaScript.

## Files
- `index.html` — page content and sections
- `style.css` — colors, layout, responsive styling, and effects
- `script.js` — mobile navigation, active section links, and footer year

## Run locally
1. Extract this ZIP folder.
2. Open the folder in VS Code.
3. Open `index.html` in your browser, or use the Live Server extension.

## Customize before submitting
1. Replace every `YOUR NAME` / `YOURNAME` with your name.
2. Change `your.email@example.com`, GitHub, and LinkedIn links in `index.html`.
3. Update the about paragraph and skills so they describe you accurately.
4. Replace the sample project cards with your actual projects and links.
5. Change the page title in `index.html`.
6. If your instructor gave a rubric, make sure your sections match it.

The portrait-style panel is a CSS monogram placeholder, not a real portrait. You can replace it with your own photo later if you want.
